import os
import re
import time
import json
from datetime import datetime

# 📂 Chemins des fichiers
LOG_FILE = "C:/Users/Utilisateurs4717/Auto-GPT/auto_gpt_workspace/ai_core/auto_evolution/evolution_log.txt"
REPAIR_LOG = "C:/Users/Utilisateurs4717/Auto-GPT/auto_gpt_workspace/ai_core/auto_repair/repair_log.txt"
KNOWN_ERRORS_FILE = "C:/Users/Utilisateurs4717/Auto-GPT/auto_gpt_workspace/ai_core/auto_repair/known_errors.json"

# ✅ Chargement des erreurs connues
def load_known_errors():
    if os.path.exists(KNOWN_ERRORS_FILE):
        with open(KNOWN_ERRORS_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    return {}

# ✅ Enregistrement des erreurs détectées
def log_error(error_message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(REPAIR_LOG, "a", encoding="utf-8") as log_file:
        log_file.write(f"[{timestamp}] ERREUR DÉTECTÉE: {error_message}\n")
    print(f"⚠️ [ALERTE] Erreur détectée : {error_message}")

# ✅ Détection des erreurs dans les logs
def detect_errors():
    known_errors = load_known_errors()
    with open(LOG_FILE, "r", encoding="utf-8") as log_file:
        log_lines = log_file.readlines()

    for line in log_lines:
        for error_pattern, solution in known_errors.items():
            if re.search(error_pattern, line):
                log_error(line.strip())
                return error_pattern, solution

    return None, None
# ✅ Chargement des erreurs connues avec gestion des erreurs
def load_known_errors():
    if os.path.exists(KNOWN_ERRORS_FILE):
        try:
            with open(KNOWN_ERRORS_FILE, "r", encoding="utf-8") as file:
                data = json.load(file)
                if not data:  # Si le fichier est vide
                    raise ValueError("Le fichier JSON est vide.")
                return data
        except json.JSONDecodeError:
            print("⚠️ ERREUR : Fichier known_errors.json corrompu. Recharge avec une configuration par défaut.")
            return {
                "can't open file": "Vérifie que le chemin du fichier est correct et accessible.",
                "ModuleNotFoundError": "Un module est manquant. Essaie de le réinstaller avec pip.",
                "Permission denied": "Le script n'a pas les droits nécessaires. Essaie de l'exécuter en admin."
            }
    else:
        print("⚠️ ERREUR : Fichier known_errors.json introuvable. Création d’un fichier vierge.")
        with open(KNOWN_ERRORS_FILE, "w", encoding="utf-8") as file:
            json.dump({}, file, indent=4)
        return {}

# ✅ Surveillance en temps réel des logs
def monitor_logs():
    print("🛠️ Surveillance des logs en temps réel...")
    while True:
        error_pattern, solution = detect_errors()
        if error_pattern:
            print(f"🔍 Erreur détectée : {error_pattern}")
            print(f"💡 Suggestion de correction : {solution}")
            # ✅ Ici, on pourra appeler auto_fixer.py pour corriger
        time.sleep(5)  # Vérification toutes les 5 secondes

# ✅ Exécution du module
if __name__ == "__main__":
    monitor_logs()
